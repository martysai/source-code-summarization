"""
This version of julian is currently in development and is not considered stable.

"""